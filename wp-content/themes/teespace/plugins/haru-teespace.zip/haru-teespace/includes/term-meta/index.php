<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if access directly
}

require_once "include/term-meta-install-class.php";
require_once "include/helpers.php";
require_once "include/term-meta-generator-class.php";
require_once "tax-meta-fields.php";