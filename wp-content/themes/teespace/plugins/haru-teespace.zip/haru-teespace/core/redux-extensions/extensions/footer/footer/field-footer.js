/* global confirm, redux, redux_change */

!function($) {
	$(document).ready(function() {
		$("#haru_footer-select").select2();
	});
}(jQuery);